# 逐命题来源、假设与适用域

下列审计ID是定位标签，不新增数学命题，也不改变原稿编号。每个源定位包含原始路径、行号和该文件SHA-256；机器数据见 CLAIMS.json。核心证明边与应用边分别记录，解释性前后引用不自动成为证明依赖。

## L001：有限时间严格陷俘的阈值排除

原稿：`RECCVS/proofs/RECCVS_L001.md`；包内：`foundations/RECCVS_L001.md`。

| 审计ID/结论 | 直接前置 | 额外假设 | 适用域 | 原稿来源 | 边界 |
| --- | --- | --- | --- | --- | --- |
| L001.PERSIST 严格陷俘有限时间持久 | SYS、TOPO、CAUCHY | 固定有限紧光滑参考片、严格负余量、共同规范 | 该参考数据的相对强邻域 | `RECCVS/proofs/RECCVS_L001.md`，行15–32，## 证明 | 按列出的假设与域使用 |
| L001.EXCLUDE 不在N/D闭包 | L001.PERSIST、PENROSE | NEC、MGHD、非紧完备Cauchy面 | 固定候选及其邻域 | `RECCVS/proofs/RECCVS_L001.md`，行5–14，## 精确命题 | U⊂B需要另加全局可预测性/零无穷远条件 |
| L001.BH 附加可预测性下黑洞邻域 | L001.EXCLUDE、VIS | 另有全局可预测性/Kommemi陷俘遮蔽假设及适当I+识别 | 满足额外假设的邻域 | `RECCVS/proofs/RECCVS_L001.md`，行5–14，## 精确命题 | 本引理自身不给这些额外全局前提 |

## L002：受控正则约束初值曲线

原稿：`RECCVS/proofs/RECCVS_L002.md`；包内：`foundations/RECCVS_L002.md`。

| 审计ID/结论 | 直接前置 | 额外假设 | 适用域 | 原稿来源 | 边界 |
| --- | --- | --- | --- | --- | --- |
| L002.DATA 完整正则AF约束数据 | SYS、TOPO | 固定紧支持f,g与小p；Δ正性bootstrap | 整张初始面 | `RECCVS/proofs/RECCVS_L002.md`，行21–48，## 证明 | 按列出的假设与域使用 |
| L002.FAMILY 参数光滑、统一范数及非零电荷 | L002.DATA | 电荷首项非零时再给Q非零 | 固定小p族 | `RECCVS/proofs/RECCVS_L002.md`，行21–48，## 证明 | 初始膨胀不能代替未来色散 |

## L003：径向平行传播潮汐分量

原稿：`RECCVS/proofs/RECCVS_L003.md`；包内：`singularity/RECCVS_L003.md`。

| 审计ID/结论 | 直接前置 | 额外假设 | 适用域 | 原稿来源 | 边界 |
| --- | --- | --- | --- | --- | --- |
| L003.TIDAL Ric(L,L)与PP角向潮汐 | SYS、VIS、POS_DOMAIN | 仿射径向L与平行角框架 | 实际零线光滑段 | `RECCVS/proofs/RECCVS_L003.md`，行1–16，# RECCVS-L003：径向平行传播潮汐分量 | 标量K、有限参数、可见性另证 |

## L004：中心出射线对数聚焦

原稿：`RECCVS/proofs/RECCVS_L004.md`；包内：`geometry/RECCVS_L004.md`。

| 审计ID/结论 | 直接前置 | 额外假设 | 适用域 | 原稿来源 | 边界 |
| --- | --- | --- | --- | --- | --- |
| L004.IDENTITY 仿射/面积聚焦恒等式 | SYS、VIS、REG_CENTER、POS_DOMAIN | r_s(0)=b>0；面积式只在r_s>0 | 实际正膨胀段 | `RECCVS/proofs/RECCVS_L004.md`，行33–46，## 证明 | 按列出的假设与域使用 |
| L004.LOG 完备有界半径的对数障碍 | L004.IDENTITY | S=∞、r_s>0、r≤RH | 该完整实际线 | `RECCVS/proofs/RECCVS_L004.md`，行5–32，## 精确陈述 | 有限S的退化版本同节；不推出曲率发散 |
| L004.FINITE 有限仿射正半径膨胀退化的能量障碍 | L004.IDENTITY | S<∞、r→R*>0、r_s→0；仍在r_s>0段 | 该线的有限仿射端 | `RECCVS/proofs/RECCVS_L004.md`，行5–32，## 精确陈述 | 即使端点可光滑继续也成立；不验收曲率奇异 |
| L004.NOBH 限定覆盖类中无黑洞 | L004.IDENTITY | 每条线完整、积分有界、全域由这些线覆盖、同一完整I+识别 | 仅满足全部额外假设的类 | `RECCVS/proofs/RECCVS_L004.md`，行47–54，## 明确限定类中的禁止结论 | 按列出的假设与域使用 |

## L005：电荷—聚焦与光滑反误判例

原稿：`RECCVS/proofs/RECCVS_L005.md`；包内：`geometry/RECCVS_L005.md`。

| 审计ID/结论 | 直接前置 | 额外假设 | 适用域 | 原稿来源 | 边界 |
| --- | --- | --- | --- | --- | --- |
| L005.CHARGE 电荷—聚焦Cauchy–Schwarz | SYS、L004.IDENTITY | Q(0)=0；面积版需r_s>0 | 实际有限零线 | `RECCVS/proofs/RECCVS_L005.md`，行5–32，## 电荷不等式的精确陈述与证明 | 迫使陷俘还需振幅积分上界与另一膨胀负号 |
| L005.COUNTER 能量发散而潮汐有界的局部实现 | SYS、CHAR | 给定实际相容两特征边；正半径 | 局部光滑反例片 | `RECCVS/proofs/RECCVS_L005.md`，行33–58，## 完全光滑的局部面积能量发散 | 不是I001正则中心全局模型 |

## L006：小数据全局接口与部分完备性

原稿：`RECCVS/proofs/RECCVS_L006.md`；包内：`foundations/RECCVS_L006.md`。

| 审计ID/结论 | 直接前置 | 额外假设 | 适用域 | 原稿来源 | 边界 |
| --- | --- | --- | --- | --- | --- |
| L006.GLOBAL 小数据归一化与全局解接口 | SYS、L002.DATA、L002.FAMILY、KL | 固定e与N≥14；转换后来源范数足够小 | L002充分小族 | `RECCVS/proofs/RECCVS_L006.md`，行27–55，## 约束族进入来源数据空间；`RECCVS/proofs/RECCVS_L006.md`，行16–26，## 归一化转换：固定 e 的合法同构 | 按列出的假设与域使用 |
| L006.RADIAL 所有径向零线完整 | L006.GLOBAL | 来源C0与好角向导数界；中心穿越 | 该小数据发展中的径向零线 | `RECCVS/proofs/RECCVS_L006.md`，行56–73，## 从估计直接补出的几何结论 | 按列出的假设与域使用 |
| L006.INNERCONE 最终内锥因果线完整 | L006.GLOBAL | 固定η>0，晚时ρ≤(1-η)t；连接系数可积 | 满足内锥条件的因果线 | `RECCVS/proofs/RECCVS_L006.md`，行56–73，## 从估计直接补出的几何结论 | 全部非径向外锥线和完整I+仍缺 |

## L007：有限时间实际内侧未陷俘薄带

原稿：`RECCVS/proofs/RECCVS_L007.md`；包内：`geometry/RECCVS_L007.md`。

| 审计ID/结论 | 直接前置 | 额外假设 | 适用域 | 原稿来源 | 边界 |
| --- | --- | --- | --- | --- | --- |
| L007.STRIP 每个有限T实际未陷俘薄带 | SYS、I001 | 有限T已存在内侧区与RN横向jets、紧域C4界 | 0<U≤bT，1≤t≤T | `RECCVS/proofs/RECCVS_L007.md`，行26–48，## 证明及宽度 | 按列出的假设与域使用 |
| L007.ZEROJETS 精确接合没有非零视界jet尾系数 | I001、HORIZON | 全部标量jets为零 | 该精确形成输入 | `RECCVS/proofs/RECCVS_L007.md`，行49–57，## 确切推进与未覆盖部分 | 按列出的假设与域使用 |

## L008：全入射截面聚焦与三次跨越

原稿：`RECCVS/proofs/RECCVS_L008.md`；包内：`geometry/RECCVS_L008.md`。

| 审计ID/结论 | 直接前置 | 额外假设 | 适用域 | 原稿来源 | 边界 |
| --- | --- | --- | --- | --- | --- |
| L008.PREFIX 视界前缀积分与膨胀号 | SYS、POS_DOMAIN | 完整实际前缀；ν传播可由MGHD提供 | 单条入射前缀 | `RECCVS/proofs/RECCVS_L008.md`，行5–25，## 1. 不需要中心边界的视界积分 | 按列出的假设与域使用 |
| L008.CENTER 完整中心截面的积分因子公式 | SYS、REG_CENTER、POS_DOMAIN | 该截面确实连接中心；ν<0 | 该截面全部正半径点 | `RECCVS/proofs/RECCVS_L008.md`，行26–55，## 2. 在确实到达正则中心的截面上使用面积半径 | 按列出的假设与域使用 |
| L008.ONECROSS 一次跨越充分排除陷俘 | L008.CENTER | 外端λH≥0；实际Q/r满足指定一次跨越 | 单截面 | `RECCVS/proofs/RECCVS_L008.md`，行56–68，## 3. 单次跨越充分条件：控制整张截面 | 跨越条件的全时间传播尚未证明 |
| L008.THREECROSS 深部陷俘至少三次跨越 | L008.CENTER | 晚时极端外端、Q_r(M)=0、完整中心截面 | 该截面 | `RECCVS/proofs/RECCVS_L008.md`，行69–79，## 4. 深部陷俘必须伴随至少三次电荷—半径跨越 | 按列出的假设与域使用 |

## L009：全时间未陷俘楔域

原稿：`RECCVS/proofs/RECCVS_L009.md`；包内：`geometry/RECCVS_L009.md`。

| 审计ID/结论 | 直接前置 | 额外假设 | 适用域 | 原稿来源 | 边界 |
| --- | --- | --- | --- | --- | --- |
| L009.WEDGE 楔域几何/场统一bootstrap | SYS、HORIZON、L008.PREFIX、L010.TRANSPORT | N,A固定；先定粗常数后缩c,η | Ut≤c的实际过去矩形 | `RECCVS/proofs/RECCVS_L009.md`，行46–89，## 2. 几何bootstrap：电荷扰动比半径缺口高阶；`RECCVS/proofs/RECCVS_L009.md`，行90–123，## 3. 场bootstrap：保留纯相位的结构 | 按列出的假设与域使用 |
| L009.EXIST 同一全时间楔域发展 | L009.WEDGE、CHAR | 低阶正半径界及每个有限矩形高阶输运 | 0≤U≤η，t≥1，Ut≤c | `RECCVS/proofs/RECCVS_L009.md`，行124–143，## 4. 有限时间延续，及如何得到同一个全时间域 | 按列出的假设与域使用 |
| L009.ACTUAL 楔域识别进同一Cauchy发展 | L009.EXIST、I001、INSEG | 共同实际边、几何唯一性/MGHD接口 | 原形成种子的楔域 | `RECCVS/proofs/RECCVS_L009.md`，行124–143，## 4. 有限时间延续，及如何得到同一个全时间域 | 按列出的假设与域使用 |

## L010：中心相容与电流号障碍

原稿：`RECCVS/proofs/RECCVS_L010.md`；包内：`geometry/RECCVS_L010.md`。

| 审计ID/结论 | 直接前置 | 额外假设 | 适用域 | 原稿来源 | 边界 |
| --- | --- | --- | --- | --- | --- |
| L010.TRANSPORT 共变波输运与Wilson积分 | SYS、POS_DOMAIN | A_t=0、P=D_Uφ、T=D_tφ | 实际光滑正半径片 | `RECCVS/proofs/RECCVS_L010.md`，行5–27，## 1. 共变输运方程 | 按列出的假设与域使用 |
| L010.CENTER 中心复积分必要相容 | L010.TRANSPORT、REG_CENTER | 入射段到中心；晚时视界T=0 | 仍正则的完整中心截面 | `RECCVS/proofs/RECCVS_L010.md`，行28–47，## 2. 正则中心给出的复积分条件 | 不是全部四维中心光滑性的充分条件 |
| L010.PHASE 电流号不由正能量决定 | SYS、CHAR | 两组局部相容角点/特征数据 | 局部正半径反例 | `RECCVS/proofs/RECCVS_L010.md`，行48–59，## 3. 单次跨越没有由能量给出的最大值原理 | 按列出的假设与域使用 |

## L011：全剩余域正通量预算

原稿：`RECCVS/proofs/RECCVS_L011.md`；包内：`geometry/RECCVS_L011.md`。

| 审计ID/结论 | 直接前置 | 额外假设 | 适用域 | 原稿来源 | 边界 |
| --- | --- | --- | --- | --- | --- |
| L011.BUDGET 每条实际线的必要充分预算 | SYS、POS_DOMAIN | 真实起点；中心起点另要求REG_CENTER | 已有实际出射线光滑段 | `RECCVS/proofs/RECCVS_L011.md`，行5–26，## 1. 每条实际出射线上的必要充分预算 | 按列出的假设与域使用 |
| L011.WILSON 晚时预算的Wilson表示 | L011.BUDGET、L010.TRANSPORT、INSEG | 视界T=0；形成期通量单独扣除 | 晚时实际连通域 | `RECCVS/proofs/RECCVS_L011.md`，行27–48，## 2. 将未知的出射尾部换成实际入射积分 | 按列出的假设与域使用 |
| L011.WEDGE 楔域正预算闭合 | L011.BUDGET、L009.WEDGE | 同一楔域内高阶平坦性 | Ut≤c | `RECCVS/proofs/RECCVS_L011.md`，行49–57，## 3. L009覆盖域的预算确已闭合 | 按列出的假设与域使用 |
| L011.FORCED 额外非零尾下的强制聚焦 | L011.BUDGET、TAIL_LOWER | 2β≤γ+1；线在全部未来实际存在 | 满足额外下界的线 | `RECCVS/proofs/RECCVS_L011.md`，行58–76，## 4. 有条件的晚时强制聚焦判据 | 原种子未证该尾下界；候选排除再调用L001.EXCLUDE |

## L012：固定宽度全时间实际内侧控制

原稿：`RECCVS/proofs/RECCVS_L012.md`；包内：`geometry/RECCVS_L012.md`。

| 审计ID/结论 | 直接前置 | 额外假设 | 适用域 | 原稿来源 | 边界 |
| --- | --- | --- | --- | --- | --- |
| L012.KERNEL 显式Liouville有界核表示 | SYS、POS_DOMAIN | 比较量F,Θ定义；零特征边误差 | 每个有限过去矩形 | `RECCVS/proofs/RECCVS_L012.md`，行43–79，## 2. 一个显式、有界的积分核 | 按列出的假设与域使用 |
| L012.STRIP 固定宽度全时间bootstrap | L012.KERNEL、L008.PREFIX、L010.TRANSPORT、HORIZON | 同一C∞输入；N→A→粗常数→η的选取次序 | 0≤U≤η、t≥1；r≥3/4 | `RECCVS/proofs/RECCVS_L012.md`，行80–124，## 3. 给定粗bootstrap时的几何精确估计；`RECCVS/proofs/RECCVS_L012.md`，行125–154，## 4. 场估计：以高阶平坦性吸收固定耦合；`RECCVS/proofs/RECCVS_L012.md`，行155–179，## 5. 闭合度量bootstrap | 按列出的假设与域使用 |
| L012.EXIST 固定条带实际全时间发展 | L012.STRIP、CHAR、I001、INSEG | 使用L009§4的有限矩形延续机制；同一实际边识别 | 固定条带全部有限t | `RECCVS/proofs/RECCVS_L012.md`，行180–187，## 6. 全时间存在的量词；`RECCVS/proofs/RECCVS_L009.md`，行124–143，## 4. 有限时间延续，及如何得到同一个全时间域 | 按列出的假设与域使用 |
| L012.PP 有限仿射长度与全部径向PP曲率界 | L012.STRIP、L012.EXIST、VIS | 每条固定U>0；t=1规范化框架 | 0<U≤η的固定出射线 | `RECCVS/proofs/RECCVS_L012.md`，行188–214，## 7. 有限仿射长度及有界曲率 | 长度U↓0可发散；本片没有曲率发散 |
| L012.BOUNDARY 非退化连续度量边界 | L012.STRIP、L012.KERNEL、L012.EXIST | 固定U1>0闭区间；可积源与支配收敛 | V=-1/t的正半径边界片 | `RECCVS/proofs/RECCVS_L012.md`，行215–227，## 8. 连续边界接口与保留的正则性限制 | 方程解/C²/C∞延拓未验收；MGHD内不可继续的解释另用I001全局接口 |
| L012.MGHD_EDGE 完整视界下MGHD内常规端点障碍 | L012.PP、I001、MGHD | 完整视界与实际MGHD整体双曲性；假想端点的因果过去包含全部晚时视界段 | 每条固定U>0的t→∞端 | `RECCVS/proofs/RECCVS_L012.md`，行215–227，## 8. 连续边界接口与保留的正则性限制 | 因果紧性论证待独立复核；不等于方程解延拓正则性结论 |

## L013：实际散射迹刚性与增长

原稿：`RECCVS/proofs/RECCVS_L013.md`；包内：`center/RECCVS_L013.md`。

| 审计ID/结论 | 直接前置 | 额外假设 | 适用域 | 原稿来源 | 边界 |
| --- | --- | --- | --- | --- | --- |
| L013.LIMIT 散射迹与α/t²极限 | L012.STRIP、L012.BOUNDARY | 固定同一种子；端点支配函数可积 | [a,η]极限及(0,η]增长 | `RECCVS/proofs/RECCVS_L013.md`，行40–56，## 2. 极限与正系数 | 按列出的假设与域使用 |
| L013.RIGID h=0与初始零场等价 | L013.LIMIT、L012.STRIP、L010.TRANSPORT | 先选足够大N、再缩η；常数独立于时间且选取合法 | 同一固定近视界条带 | `RECCVS/proofs/RECCVS_L013.md`，行61–81，## 4. 反向估计：不丢失Wilson相位 | 按列出的假设与域使用 |
| L013.OUTER 非零初始场提供正增长外边 | L013.RIGID、L013.LIMIT | 实际初始场在[0,η]不恒零 | 固定b=η的全时间外边 | `RECCVS/proofs/RECCVS_L013.md`，行82–89，## 5. 进入全中心估计的接口 | h与晚时阈值没有族统一界 |

## L014：抽象外边下的全余域体积与寿命

原稿：`RECCVS/proofs/RECCVS_L014.md`；包内：`center/RECCVS_L014.md`。

| 审计ID/结论 | 直接前置 | 额外假设 | 适用域 | 原稿来源 | 边界 |
| --- | --- | --- | --- | --- | --- |
| L014.VOLUME 抽象外边给全余域有限体积 | SYS、OUTER_INPUT、POS_DOMAIN、INSEG | 对实际连通前缀作单调穷尽；不预设末端中心 | 整个实际D_b余域 | `RECCVS/proofs/RECCVS_L014.md`，行24–47，## 2. 全余域有限体积：无需中心边界条件 | 按列出的假设与域使用 |
| L014.CENTER 中心截面电磁积分与加权半径界 | L014.VOLUME、REG_CENTER | 该截面确实以正则中心结束 | 仍存在中心的完整截面 | `RECCVS/proofs/RECCVS_L014.md`，行48–74，## 3. 入射段仍以正则中心结束时：全深部电磁积分与半径控制 | 按列出的假设与域使用 |
| L014.AXIS dτ/dt=1/(2α)轴线恒等式 | SYS、REG_CENTER | dr\|Γ=0、Δ→1；相容双零坐标 | 实际正则轴线 | `RECCVS/proofs/RECCVS_L014.md`，行75–105，## 4. 中心固有时间：一个精确全局接口 | 按列出的假设与域使用 |
| L014.LIFETIME 外边下中心剩余固有长度有限 | L014.AXIS、OUTER_INPUT、INSEG | 中心在固定外边更深处且仍存在 | 该正则轴线的实际剩余段 | `RECCVS/proofs/RECCVS_L014.md`，行75–105，## 4. 中心固有时间：一个精确全局接口 | 不推曲率、零仿射长度或可见性 |
| L014.EXTENSION 体积可供正半径延拓原理调用 | L014.VOLUME、KOM_EXT | 整个去端点菱形实际存在、r≥r0>0、紧初始边 | 仅满足全部延拓前提的菱形 | `RECCVS/proofs/RECCVS_L014.md`，行106–118，## 5. 能调用的正半径延续与不能调用的结论 | 按列出的假设与域使用 |

## L015：首个非零点与轴线有限固有寿命

原稿：`RECCVS/proofs/RECCVS_L015.md`；包内：`center/RECCVS_L015.md`。

| 审计ID/结论 | 直接前置 | 额外假设 | 适用域 | 原稿来源 | 边界 |
| --- | --- | --- | --- | --- | --- |
| L015.NONZERO 中心与视界电荷差强迫非零场 | SYS、I001、INSEG、REG_CENTER | 中心活到t=1，完整该截面，QH=1/QΓ=0 | 实际t=1截面 | `RECCVS/proofs/RECCVS_L015.md`，行17–29，## 2. t=1上的实际完整截面与非平凡性 | 按列出的假设与域使用 |
| L015.GAPOUTER 零场空隙后构造合法正外边 | L015.NONZERO、SYS、CHAR、I001 | 首非零点c>0；有限ERN参考矩形、固定宽度、反向Goursat唯一性 | 同一解首非零点旁条带 | `RECCVS/proofs/RECCVS_L015.md`，行50–80，## 4. 首个非零点旁的固定宽度、全部时间实际条带；`RECCVS/proofs/RECCVS_L015.md`，行30–49，## 3. c>0：只有已证零场区才识别为电真空；`RECCVS/proofs/RECCVS_L015.md`，行81–103，## 5. 反向特征唯一性强迫增长系数为正 | w≥0选择的延拓不自动属于原MGHD |
| L015.OUTER 两种非零起点情形均提供外边 | L015.NONZERO、L013.OUTER、L015.GAPOUTER | c=0用L012–13；c>0用本稿§3–5 | 中心活到t=1时同一实际全时间外边 | `RECCVS/proofs/RECCVS_L015.md`，行5–16，## 1. 命题：去除近视界非零假设 | 按列出的假设与域使用 |
| L015.LIFETIME 全部轴线寿命分支固有长度有限 | L015.OUTER、L014.LIFETIME、L014.AXIS、I001 | t_end=∞用外边；t_end<∞用视界α在有限区间正下界 | 同一实际MGHD轴线 | `RECCVS/proofs/RECCVS_L015.md`，行104–122，## 6. 轴线有限寿命的完整分情况 | 这一层不依赖先证明曲率奇异或深部λ号 |

## L016：正则中心曲率与物理导数

原稿：`RECCVS/proofs/RECCVS_L016.md`；包内：`center/RECCVS_L016.md`。

| 审计ID/结论 | 直接前置 | 额外假设 | 适用域 | 原稿来源 | 边界 |
| --- | --- | --- | --- | --- | --- |
| L016.CURVATURE 中心精确曲率/质量恒等式 | SYS、REG_CENTER | 旋转对称、无磁荷；逐事件中心极限 | 四维实际正则中心 | `RECCVS/proofs/RECCVS_L016.md`，行37–56，## 3. Einstein方程及Riemann分解 | 不依赖I001、L012或L015 |
| L016.PHYSICAL Dτφ=4αT=P/(-ν) | L014.AXIS、REG_CENTER | 中心空间共变梯度为零 | 实际正则轴线 | `RECCVS/proofs/RECCVS_L016.md`，行57–71，## 4. 双零导数与物理导数的区别 | 按列出的假设与域使用 |
| L016.SINGULAR 有限固有时曲率判据 | L016.CURVATURE、L016.PHYSICAL、L015.LIFETIME | 另加limsup\|αΓTΓ\|=∞ | 该轴线有限固有时端点 | `RECCVS/proofs/RECCVS_L016.md`，行72–83，## 5. 已知有限寿命之后的准确曲率判据 | 增长前提未证；趋轴邻域与零仿射/可见性另证 |

## L017：中心电荷的尖锐径向能量障碍

原稿：`RECCVS/proofs/RECCVS_L017.md`；包内：`center/RECCVS_L017.md`。

| 审计ID/结论 | 直接前置 | 额外假设 | 适用域 | 原稿来源 | 边界 |
| --- | --- | --- | --- | --- | --- |
| L017.POINCARE 加权Poincaré与ground-state分解 | BESSEL | 中心有界且足够光滑的复f，f(R)=0；相容端点极限 | 独立径向函数类 | `RECCVS/proofs/RECCVS_L017.md`，行30–51，## 2. 加权 Poincaré 不等式及其证明 | 按列出的假设与域使用 |
| L017.SHARP S≥4j\|Q\|/(\|e\|R²)与径向尖锐性 | SYS、REG_CENTER、L017.POINCARE | 完整入射截面、Q(0)=0、φ(R)=0；Wilson输运 | 该截面及独立径向函数类 | `RECCVS/proofs/RECCVS_L017.md`，行52–80，## 3. 完成平方：同时保留场幅度和相位 | 径向极值不认证全时空约束实现 |
| L017.RATIO 极端截面αΓ/αH下界 | L017.SHARP、SYS | R=M、\|Q\|=M；仍连接正则中心 | 该极端完整截面 | `RECCVS/proofs/RECCVS_L017.md`，行81–93，## 4. 它闭合什么、不闭合什么 | φ_r(R)=0给严格性但无统一间隙；不决定陷俘号 |

## L018：有限实际区间谱陷俘判据

原稿：`RECCVS/proofs/RECCVS_L018.md`；包内：`collapse/RECCVS_L018.md`。

| 审计ID/结论 | 直接前置 | 额外假设 | 适用域 | 原稿来源 | 边界 |
| --- | --- | --- | --- | --- | --- |
| L018.SIGN 首谱值与实际端点膨胀同号 | SYS、VIS、FINITE_INTERVAL、SL | 真实V；r>0与ν<0 | 有限实际区间 | `RECCVS/proofs/RECCVS_L018.md`，行38–53，## 2. 证明：不预设未陷俘 | 按列出的假设与域使用 |
| L018.CERT 正/负有限区间积分证书 | L018.SIGN | 可靠V_-≤V≤V_+；实际区间存在 | 该有限区间 | `RECCVS/proofs/RECCVS_L018.md`，行54–72，## 3. 无须本征求解的有限时间证书 | 按列出的假设与域使用 |
| L018.CENTER 中心χ与二阶物理导数桥梁 | L018.CERT、REG_CENTER | χ>0；ell=π/√χ的整段存在；\|D_L²φ\|≤χ/(2π) | 从该中心发出的实际有限线 | `RECCVS/proofs/RECCVS_L018.md`，行73–92，## 4. 从中心物理导数到陷俘的定量桥梁 | χ大本身不提供存在长度或二阶界 |
| L018.ROBIN 正半径初点Robin版本 | L018.SIGN | 记录w0=r_s(0)/r(0)，固定仿射尺度 | 不从中心起算的实际段 | `RECCVS/proofs/RECCVS_L018.md`，行93–102，## 5. 不从中心起算的实际线 | 按列出的假设与域使用 |

## L019：内部边际球刚性与仿射预算

原稿：`RECCVS/proofs/RECCVS_L019.md`；包内：`collapse/RECCVS_L019.md`。

| 审计ID/结论 | 直接前置 | 额外假设 | 适用域 | 原稿来源 | 边界 |
| --- | --- | --- | --- | --- | --- |
| L019.FIRST 内部首次触零刚性 | SYS、POS_DOMAIN | U内部点；U邻域λ≥0才能推λ_U=0 | 有限紧实际光滑片内的正半径球 | `RECCVS/proofs/RECCVS_L019.md`，行5–21，## 1. 首次触零的约束 | 按列出的假设与域使用 |
| L019.BUDGET 无陷俘未来边际射线预算 | L019.FIRST、L010.TRANSPORT | 每个未来点的U邻域λ≥0；整段实际存在 | 该内部边际射线 | `RECCVS/proofs/RECCVS_L019.md`，行22–56，## 2. 无陷俘假设下的整个未来边际射线 | φ0≠0才有有限预算；超预算但仍存在才推出陷俘 |

## L020：固定八阶领先剖面证书

原稿：`RECCVS/proofs/RECCVS_L020.md`；包内：`collapse/RECCVS_L020.md`。

| 审计ID/结论 | 直接前置 | 额外假设 | 适用域 | 原稿来源 | 边界 |
| --- | --- | --- | --- | --- | --- |
| L020.PROFILE 固定有理剖面与八个零矩 | E020 | K=8,n=88,σ=1/20；能量归一化 | 辅助半线x≥0 | `RECCVS/proofs/RECCVS_L020.md`，行5–32，## 1. 全部参数固定 | 按列出的假设与域使用 |
| L020.CURRENT 正电流滤波论证 | L020.PROFILE | 高斯有理多项式及上半平面根结构 | x>0辅助剖面 | `RECCVS/proofs/RECCVS_L020.md`，行33–45，## 2. 正电流的解析证明 | 按列出的假设与域使用 |
| L020.J J恰一次简单负到正变号 | L020.PROFILE、E020 | 精确分子与六叶整数覆盖证书 | 紧化全半线 | `RECCVS/proofs/RECCVS_L020.md`，行46–75，## 3. 一次变号的整数证书 | 按列出的假设与域使用 |
| L020.KERNEL 𝒦单调且≥𝒦(0)>2^-854 | L020.PROFILE、L020.J、KDEF | 核ODE/边界按KDEF；正端点精确比较 | 全辅助半线 | `RECCVS/proofs/RECCVS_L020.md`，行76–112，## 4. 从正性升级为单调性和端点最小值 | 按列出的假设与域使用 |

## L021：截断、矩修复与周期族

原稿：`RECCVS/proofs/RECCVS_L021.md`；包内：`collapse/RECCVS_L021.md`。

| 审计ID/结论 | 直接前置 | 额外假设 | 适用域 | 原稿来源 | 边界 |
| --- | --- | --- | --- | --- | --- |
| L021.FIX 光滑截断与精确零矩修复 | L020.PROFILE、L020.CURRENT | 固定ρ,bump与积分矩阵A；A^-1解析有界 | 单块紧支持剖面 | `RECCVS/proofs/RECCVS_L021.md`，行51–78，## 3. 矩矩阵的明确可逆性；`RECCVS/proofs/RECCVS_L021.md`，行5–34，## 1. 固定的光滑函数；`RECCVS/proofs/RECCVS_L021.md`，行35–50，## 2. 截断误差的实数上界 | 这里精确不意味着所有超越积分都是有理数 |
| L021.CORE 电流核心可靠正余量 | L020.PROFILE、E021 | 核心Bernstein正性与小C1修复 | [3/4,33/4]及修复核心 | `RECCVS/proofs/RECCVS_L021.md`，行79–90，## 4. 电流核心的精确包络 | 按列出的假设与域使用 |
| L021.FAMILY 周期族M_s(z_c)=c_s | L021.FIX、L021.CORE | 固定T及\|c_s\|≤2^-4096；共同端点开空隙 | 整个具体周期族 | `RECCVS/proofs/RECCVS_L021.md`，行91–110，## 5. 固定周期与半线矩坐标 | 按列出的假设与域使用 |
| L021.KERNEL λ<3/5与周期核>2^-855 | L021.FAMILY、L020.KERNEL、KDEF | 单块L1比较与周期精确求和 | 全周期半线及参数球 | `RECCVS/proofs/RECCVS_L021.md`，行111–141，## 6. 核与耦合余量 | 实际形成另需有限振幅FLIFT实例 |

## L022：光滑尾界与锥/时空误差预算

原稿：`RECCVS/proofs/RECCVS_L022.md`；包内：`collapse/RECCVS_L022.md`。

| 审计ID/结论 | 直接前置 | 额外假设 | 适用域 | 原稿来源 | 边界 |
| --- | --- | --- | --- | --- | --- |
| L022.TAIL 同一光滑极限固定Ck尾界 | FSMOOTH | 每步确实满足δ_*2^-n；N≥k+1 | 同一修复序列 | `RECCVS/proofs/RECCVS_L022.md`，行5–22，## 1. 尾部不是无控制的无限对象 | 按列出的假设与域使用 |
| L022.CONE 显式锥几何安全预算 | SYS | 参考r/t≥a,H/t≥h,β>0与场范数已认证 | 同一仿射锥[0,1] | `RECCVS/proofs/RECCVS_L022.md`，行23–95，## 2. 不含隐藏连续依赖常数的锥几何预算 | a,h,β尚需具体有限成员 |
| L022.FLOW 修复尾误差的实际W传播 | L022.TAIL、COMMON_FLOW | 共同域、同一物理线、经过证明的C_flow | 该共同有限实际域 | `RECCVS/proofs/RECCVS_L022.md`，行96–110，## 3. 真正的时空传播还需要什么 | 这是尚未取得输入的条件性接口 |
| L022.DECISION 总误差下正/负谱判决 | L022.FLOW、L018.CERT | 可靠数值包络、严格余量ρ、总误差满足门槛 | 同一有限实际区间 | `RECCVS/proofs/RECCVS_L022.md`，行111–136，## 4. 尾部误差与数值误差合并后的判决 | 不是原种子的已完成实际符号证书 |

## L023：第一周期严格陷俘机制

原稿：`RECCVS/proofs/RECCVS_L023.md`；包内：`collapse/RECCVS_L023.md`。

| 审计ID/结论 | 直接前置 | 额外假设 | 适用域 | 原稿来源 | 边界 |
| --- | --- | --- | --- | --- | --- |
| L023.ANLIM 保守充分条件给严格陷俘 | SYS、ANLIM、MINK_FILL、POS_DOMAIN | 23.1及完整外部经典发展接口；边际升级保持Q²/r²<1 | 有限第一周期特征发展 | `RECCVS/proofs/RECCVS_L023.md`，行5–37，## 1. 外部接口和归一化审计 | 按列出的假设与域使用 |
| L023.FIRST 第一周期质量/半径/电荷/物理宽度 | FLIFT、MINK_FILL | 真实有限根；固定可行周期族；q≤bδ，C≥0 | 真实第一物理周期[t1,t2] | `RECCVS/proofs/RECCVS_L023.md`，行58–99，## 3. 第一物理周期的质量集中：精确而非平均展开；`RECCVS/proofs/RECCVS_L023.md`，行100–125，## 4. 第一周期电荷小，但不能略过仿射尺度 | 按列出的假设与域使用 |
| L023.BRANCH 充分长指定分支严格陷俘 | L023.FIRST、L023.ANLIM、FLIFT | 23.6；c_m,τ_m,ρ_m的真实分支渐近 | 指定完整Minkowski填充分支 | `RECCVS/proofs/RECCVS_L023.md`，行126–162，## 5. 分支负号结论 | 不是全部极端形成解的禁止定理 |
| L023.MGEOM L021族显式几何长度门槛 | L021.KERNEL、L021.FAMILY、L023.FIRST、E023 | μ=3/5、指定τ带、m≥2^2104156 | 该具体族的几何充分条件 | `RECCVS/proofs/RECCVS_L023.md`，行140–162，### L021族的显式几何长度门槛 | 端点根门槛m_lift仍非有效 |
| L023.SMOOTH 可选择修复保留陷俘并排除候选 | L023.BRANCH、FSMOOTH、CAUCHY、L001.EXCLUDE | 共同特征/Cauchy实现；实际输入强范数误差<ε_trap | 选定有限成员及足够小修复的光滑极限 | `RECCVS/proofs/RECCVS_L023.md`，行163–175，## 6. 光滑修复及目标的准确影响 | 具体ε_trap与未冻结原光滑种子仍待认证；L022可提供尾预算 |
