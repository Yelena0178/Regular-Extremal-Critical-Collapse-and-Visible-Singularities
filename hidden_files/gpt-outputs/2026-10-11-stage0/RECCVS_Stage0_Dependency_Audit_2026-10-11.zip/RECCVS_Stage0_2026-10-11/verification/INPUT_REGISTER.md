# 输入与外部结果登记表

“条件输入”须在每次应用中被验证；来源登记不等于证明通过。公共论文仅固定附件内版本，阶段0未检索新版、勘误或重新审查全文。标准 Cauchy/Penrose 工具的精确版本尚须补定。分情况证明中的多个前置结果用于不同分支，不表示所有相应额外假设须在一个分支中同时成立。

| ID | 名称/状态 | 准确输入 | 前置模块 | 来源与定位 |
| --- | --- | --- | --- | --- |
| SYS | D001：EMCSF 归一化；定义输入 | 四维、球对称、无质量复标量、无磁荷、固定 e≠0；签名与 Maxwell 取向按 MODEL.md。 | 无项目前置 | `RECCVS/definitions/MODEL.md`；RECCVS-D001 |
| TOPO | D002–D003：强拓扑与色散集合；定义输入 | 约束空间 X^s，s≥6；AF/Coulomb 主项单列；D 要求所有因果测地完整、完整 I+ 与衰减。 | 无项目前置 | `RECCVS/definitions/MODEL.md`；RECCVS-D002、D003 |
| VIS | D004：物理归一化与可见性；定义输入 | 零线仿射或类时固有时；框架在固定物理初点归一化；可见性接到同一完整 I+。 | 无项目前置 | `RECCVS/definitions/MODEL.md`；RECCVS-D004 |
| REG_CENTER | 实际正则中心；条件输入 | 四维实际光滑正则中心；Q=O(r^3)、m=O(r^3)，中心取极限；使用时必须标明该中心事件仍属于实际发展。 | 无项目前置 | `RECCVS/definitions/MODEL.md`； |
| POS_DOMAIN | 实际正半径光滑域；条件输入 | r>0、Ω²>0、ν<0；所积分的段确实存在于同一实际解；未来双零方向取向固定。 | 无项目前置 | `RECCVS/definitions/MODEL.md`； |
| INSEG | 同一实际入射连通段；条件输入 | 由 U=0 至所考察点的正半径前缀属于实际发展；只有明确到达正则中心时才使用中心端边项。 | 无项目前置 | `RECCVS/inputs/AUDIT.md`；`RECCVS/inputs/formation/RN-Black-Hole-Lab/proof/04_global_development_and_horizon.md`； |
| HORIZON | 全零 jets 的晚时极端视界数据；条件输入 | M=Q_H=1，U=0、t≥1：r=Q=Ω²=1、λ=φ=0、ν=-a0<0，横向标量 jets 全零；t=1 内侧数据属于同一光滑种子。 | 无项目前置 | `RECCVS/inputs/AUDIT.md`；`RECCVS/proofs/RECCVS_L009.md`；`RECCVS/proofs/RECCVS_L012.md`； |
| OUTER_INPUT | L014.1：抽象外边输入；条件输入 | 固定 U=b 的全部 t≥1 外边：0<r_b≤R≤1、λ_b≥0、r_bλ_b≤C_b/t²、α_b/t²→h_b>0、α_b≥a0。 | 无项目前置 | `RECCVS/proofs/RECCVS_L014.md`；§1，L014.1 |
| FINITE_INTERVAL | 实际有限仿射区间；条件输入 | 中心归一化 γ 在 [0,ell] 实际光滑存在，r(s)>0 对 s>0；正半径起点版本另记录 r_s(0)/r(0)。 | 无项目前置 | `RECCVS/proofs/RECCVS_L018.md`； |
| TAIL_LOWER | 实际非零尾部下界；未取得的条件 | 同一实际线对全部 t≥t1 存在且 r≥r_->0、Ω²≤C(1+t)^(-γ)、\|T\|≥c(1+t)^(-β)，c>0。 | 无项目前置 | `RECCVS/proofs/RECCVS_L011.md`；L011.4；不是现有种子的已知尾部 |
| COMMON_FLOW | 共同实际域与流误差；未取得的条件 | 共同紧光滑域、同一物理初点/仿射归一化、Wilson 比较；强范数输入差到实际 W 的 C_flow 界。 | 无项目前置 | `RECCVS/proofs/RECCVS_L022.md`；§3 |
| MINK_FILL | 完整 Minkowski 入射填充；尚未冻结的条件 | 从左端球面至中心的整条初始入射锥为 Minkowski；共同 Cauchy 实现包含相应有限依赖域。 | 无项目前置 | `RECCVS/proofs/RECCVS_L023.md`；§2；不是仅球面 jets 或局部平直空隙 |
| PERIODIC_PROFILE | 有限阶提升的周期族假设；抽象条件 | 固定 K、T、紧 c 球；光滑周期 z_c、端点共同开空隙、均值 E/C 正、C≥0、λ<μ、形成核正。 | 无项目前置 | `RECCVS/inputs/formation/RN-Black-Hole-Lab/proof/finite_order/01_profile_construction.md`；`RECCVS/inputs/formation/RN-Black-Hole-Lab/proof/finite_order/03_nonlinear_lifting.md`； |
| KDEF | 形成核的完整定义；定义输入 | I_C(x)=∫_0^x C+∫_x^∞e^(x-y)C；I_E(x)=∫_0^x(1-e^(y-x)/2)E+(1/2)∫_x^∞e^(x-y)E；𝒦=2λI_C-2I_E。 | 无项目前置 | `RECCVS/inputs/formation/RN-Black-Hole-Lab/proof/finite_order/01_profile_construction.md`；文件首段；给 L020 缺省记号补足来源 |
| FRBASE | 有限阶提升：半径/参数基底；内部未独立复核 | 固定周期族；q=O(δ)、q-δp=O_C1(δ²)、R 与一阶参数导数一致控制。 | PERIODIC_PROFILE | `RECCVS/inputs/formation/RN-Black-Hole-Lab/proof/finite_order/03_nonlinear_lifting.md`；§2–3 |
| FRPOS | 半径正性与初始 q 下界；内部未独立复核 | 由 Riccati 正壁、周期平均、核紧区间/尾区及有限脉冲比较取得 q≥aδ、H_L>0。 | FRBASE、KDEF、PERIODIC_PROFILE | `RECCVS/inputs/formation/RN-Black-Hole-Lab/proof/finite_order/04_radius_positivity.md`；§1–5 |
| FENDPOINT | 有限阶背景端点与完整球面数据；内部未独立复核 | 多项式 Volterra 核、非零下三角对角元、KU D_K 最高阶字段。 | SYS | `RECCVS/inputs/formation/RN-Black-Hole-Lab/proof/finite_order/02_endpoint_matching.md`；§1–5 |
| FLIFT | 有限阶非线性分支存在；内部未独立复核；非有效门槛 | 对每个充分大 m 存在局部精确根 (c_m,τ_m)，c_m→0、τ_m→τ0；17 维具体根仍未认证。 | FRBASE、FRPOS、FENDPOINT | `RECCVS/inputs/formation/RN-Black-Hole-Lab/proof/finite_order/03_nonlinear_lifting.md`；§4–6；K=8 时为 17 个实条件 |
| FLOCAL | Bondi 共同低阶寿命；内部未独立复核 | 有符号半径 Bondi 光滑解、完整正半径方程、固定阶中心响应及参数 C1 控制。 | SYS | `RECCVS/inputs/formation/RN-Black-Hole-Lab/proof/02_smooth_data_and_local_evolution.md`；§2–5；四维中心解释另在 FCENTER |
| FSMOOTH | 同一光滑种子与逐阶修复；内部未独立复核 | 非退化有限基族之后逐阶精确修复、同一终端空隙、可求和 C^(n-1) 与 β 预算。 | FLIFT、FLOCAL | `RECCVS/inputs/formation/RN-Black-Hole-Lab/proof/02_smooth_data_and_local_evolution.md`；§6.1–6.4 |
| FCENTER | 实际四维中心、接合与 cap；内部未独立复核 | 中心奇偶、实际笛卡尔实现、一次 ERN 边值实现、共同条带和顶点填充。 | FSMOOTH、FLOCAL、CHAR、CAUCHY | `RECCVS/inputs/formation/RN-Black-Hole-Lab/proof/03_regular_center_and_gluing.md`；§2–5 |
| FGLOBAL | 全局 Cauchy/外部/视界识别；内部未独立复核 | 实际保留域、单端 AF Cauchy 面、MGHD 识别、完整 I+ 及视界从中心出发。 | FCENTER、MGHD、CHAR | `RECCVS/inputs/formation/RN-Black-Hole-Lab/proof/04_global_development_and_horizon.md`；§2–6 |
| I001 | 导入的光滑极端形成输入；组合性内部输入 | 固定 eM>1/2 的一份同一光滑、正则中心、单端 AF、真正塌缩形成解；全局标签/晚时精确 ERN 按导入稿。 | FGLOBAL | `RECCVS/inputs/AUDIT.md`；`RECCVS/inputs/formation/RN-Black-Hole-Lab/proof/01_main_theorem.md`；AUDIT.md 的 I001 及主定理；没有临界族或非零视界尾部 |
| I002 | 限定视界类的严格半门槛；内部计算输入 | 限定正则起源、有限时间精确端点等假设下 \|e\|M>1/2；不是一般渐近极端禁止结果。 | SYS | `RECCVS/inputs/AUDIT.md`；`RECCVS/inputs/formation/RN-Black-Hole-Lab/proof/05_strict_half_threshold.md`；AUDIT.md 的 I002；L001–L023 核心 DAG 无需该输入 |
| CHAR | 正半径特征适定与约束传播；外部来源待逐项复核 | KU 2211.15742 Proposition 2.1/Remark 2.1，球面数据 Proposition 2.3；GL 1709.09137 §10 的局部约束机制。 | 无项目前置 | `RECCVS/literature/2211.15742.txt`；`RECCVS/literature/1709.09137.txt`；仅局部工具；GL 弱耦合全局主定理不在此输入内 |
| MGHD | 球对称全局商空间与 ν 传播；外部来源待逐项复核 | Kommemi 1107.0949v2 Proposition 2.1、3.1 及实际域接口，保留约定与连通性假设。 | 无项目前置 | `RECCVS/literature/1107.0949.txt`； |
| KOM_EXT | 正半径延拓原理；外部来源待逐项复核 | Kommemi Theorem 1.8/§4：整个去端点因果菱形在实际发展，r 有正下界且体积有限。 | 无项目前置 | `RECCVS/literature/1107.0949.txt`；r=0 端点与已有 CH 片不能直接验收 |
| CAUCHY | 有限时间强拓扑 Cauchy 稳定性；标准工具；明确版本/定理号未固定 | 固定谐和/Lorenz 规范；共同有限光滑参考片及足够高 Sobolev 控制，约束/规范传播与几何唯一性。 | 无项目前置 | `RECCVS/proofs/RECCVS_L001.md`；`RECCVS/inputs/formation/RN-Black-Hole-Lab/proof/03_regular_center_and_gluing.md`；L001 证明1–3；形成 proof/03 §1；见缺口 G01 |
| PENROSE | Penrose 零测地不完备定理；标准工具；明确版本/定理号未固定 | NEC、整体双曲、非紧 Cauchy 面、闭严格陷俘二曲面。 | 无项目前置 | `RECCVS/proofs/RECCVS_L001.md`；L001 证明4–5；见 G01 |
| KL | Kauffman–Lindblad 小数据定理；外部来源待逐项复核 | 2109.03270v2 Theorem 11.1，固定 N≥14、γ∈(1/2,1)，转换后加权数据范数足够小。 | 无项目前置 | `RECCVS/literature/2109.03270.txt`；`RECCVS/proofs/RECCVS_L006.md`；L006 §1–3；公开源状态按附件版本固定 |
| ANLIM | An–Lim 带电陷俘形成接口；外部来源及归一化待独立复核 | 2005.04090v1 Theorem 1.3、证明(2.16)及§3；正确物理宽度、初始两锥及实际发展接口。 | 无项目前置 | `RECCVS/literature/2005.04090.txt`；`RECCVS/proofs/RECCVS_L023.md`；L023 §1；R05 待办 |
| SL | 有限区间 Sturm–Liouville 工具；标准工具；稿内给出所需主要恒等式 | 有界实际 V≥0、H1 稠密性、紧嵌入与首 Rayleigh 值取到。 | 无项目前置 | `RECCVS/proofs/RECCVS_L018.md`；§1–3；不提供实际 V 的误差包络 |
| BESSEL | J0 首零点与加权 Poincaré；标准特殊函数工具 | J0(jx)>0 对 0≤x<1，J0(j)=0；j=j0,1；稿内给出 ground-state 与边项论证。 | 无项目前置 | `RECCVS/proofs/RECCVS_L017.md`；§2–3 |
| E020 | L020 历史有理/整数证书；附件中已有；本轮未重跑数学认证 | 固定剖面、矩、J 分子、Bernstein/Descartes 覆盖；验收范围为领先辅助剖面。 | 无项目前置 | `RECCVS/experiments/freeze_filtered_profile.py`；`RECCVS/experiments/certify_filtered_J.py`；`RECCVS/experiments/filtered_K8_n88_sigma1over20.json`；`RECCVS/experiments/filtered_K8_n88_J_certificate.json`；`RECCVS/experiments/ROUND_07_VERIFICATION.md`； |
| E021 | L021 历史可行族证书；附件中已有；本轮未重跑数学认证 | 精确有理系数/核心 Bernstein 包络；光滑 cutoff、bump 与超越积分矩阵的证明仍在正文。 | 无项目前置 | `RECCVS/experiments/certify_admissible_profile.py`；`RECCVS/experiments/filtered_K8_n88_admissible_certificate.json`；`RECCVS/experiments/ROUND_07_VERIFICATION.md`； |
| E023 | L023 历史门槛代数检查；附件中已有；本轮未重跑数学认证 | 仅检查充分条件的代数；JSON 明记 finite_amplitude_root_certified=false。 | 无项目前置 | `RECCVS/experiments/check_first_period_thresholds.py`；`RECCVS/experiments/first_period_threshold_certificate.json`； |

## 形成输入的拆分

FRBASE → FRPOS；FRBASE、FRPOS、FENDPOINT → FLIFT → FSMOOTH → FCENTER → FGLOBAL → I001。FLOCAL 从本规范的算子/局部演化论证给出，并与 FLIFT 一起供 FSMOOTH 使用。该拆分是文献依赖记录，不是对导入证明的独立认证。

PERIODIC_PROFILE 是抽象假设；L021 是具体实例。把 L021 代入 FLIFT 的实例并不等于已经得到有效门槛或具体根。I002 不承担 A 的普遍禁止结论。
