# 整段 H 正性的有效证明及同一根交接

日期：2026-10-11。这是在冻结 L020/L021 剖面证书与阶段 2 有限端点根证书之上的新增解析证明。算术复算不等于形式化定理证明，也不认证全局 PDE 发展。

## 1. 同一成员与输入

固定 K=8、T=1048578、μ=3/5、M=2104156、m=2^M、L=mT。
取阶段 2 产品盒内的唯一联合根 (c*,κ*)；不是另选一个领先根。

- 16 个实分量 |c_a|<2^-4097，故每个复 |c_j|<2^-4096。
- κ* 的精确二进制中心见 ROOT_HANDOFF.json 指向的原根证书，半径 2^-3900，7/8<κ*<1。
- δ=κ*/m，所以 (7/8)2^-M<δ<2^-M。
- 该根满足 e_L=μ 及 D_U^j Φ(0,1)=0，1≤j≤8。
- 根证书重新生成后与原文件逐字段相同；精确 16×16 逆和包含指数再次复算。

更紧的定位由 ||P||∞<64、ε_F=2^(348174-M)、q_K≤2^(348184-M) 得

\[
\max_a|c_a^*|\le\frac{64\epsilon_F}{1-q_K}<2^{348181-M}=2^{-1755975}.
\]

后文仍使用原较宽参数盒的统一估计，不依赖这个收紧盒。
对同一 z=z_{c*}，令 E=|z'|²、C=Im(\bar z z')，E_b=∫₀ᵀE，C_b=∫₀ᵀC，λ=2E_b/C_b。
冻结 L021 给出

\[
E,C\ge0,\quad \tfrac12<E_b<2,\quad2<C_b<5,\quad
0<\lambda<\tfrac35,\quad |E_b-1|<3\eta,\quad\eta=2^{-3950},
\]

\[
\sup E,\sup C<b:=2^{3201},\qquad
\mathcal K_{c,\mathrm{per}}(x)>2^{-855}\quad(x\ge0).
\]

以下正性引理事实上适用于任意这样的剖面及 0<δ≤2^-22000。根存在性另行继承；不能从这个门槛反推端点根存在。

## 2. 精确无限辅助系统与 Riccati 屏障

将同一 z 周期延拓，解

\[
q'=q^2-q+\delta E,\quad q(0)=0,\qquad R'=-qR,\quad R(0)=1.
\]

因 sup E≤b/2（|z'|<2^1600），在 q=bδ 上导数≤b²δ²-bδ/2<0，q=0 上导数非负。
所以半线上 0≤q≤bδ<1/4，R>0；解不发生有限 x 爆破。
定义 p'+p=E、p(0)=0。变常数公式给

\[
q\ge\delta p,\qquad
0\le q-\delta p=\int_0^x e^{-(x-s)}q(s)^2ds\le b^2\delta^2.
\tag{H1}
\]

**关键改进是累计能量，而非极小逐点下界。** 把 p 的卷积分成长度 T 的区间，每段能量至多 E_b，有

\[
p(x)\le\frac{E_b}{1-e^{-T}}<4,
\qquad
\int_0^{nT}p=nE_b-p(nT)\ge n/2-4.
\]

从而

\[
R(nT)\le\exp[-\delta(n/2-4)],\qquad R(x)\downarrow0.
\tag{H2}
\]

这避免把原稿的 a=e^-T E_b 用作尾区累计衰减常数。

## 3. 全半线统一电荷尾积分

置 W_x(s)=R(x+s)²/R(x)²。它从 1 单调降到 0，∫|W_x'|=1。
对一个周期函数 f，从任意相位开始的零均值原函数有

\[
\sup_{s\ge0}\left|\int_0^s(f(x+y)-\bar f)dy\right|
\le 2\int_0^T|f|.
\]

于是 E 的原函数界为 4，C 的为 10。设 a=C_b/E_b∈(1,10)，C-aE 均值为零；它的原函数界≤10+10·4=50。
分部积分无穷远边界消失，给

\[
\left|\delta\int_0^\infty(C-aE)(x+s)W_x(s)ds\right|\le50\delta.
\]

Riccati 的精确积分恒等式为

\[
\delta\int_x^\infty E R^2=(1/2-q(x))R(x)^2+\int_x^\infty q^2R^2.
\]

又 ∫ₓ∞qR²=R(x)²/2，最后一项≤bδ R(x)²/2。因此，令

\[
I(x)=\delta\int_0^\infty C(x+s)W_x(s)ds,\quad A=a/2=1/\lambda,
\]

便有全 x 一致的显式界

\[
|I(x)-A|\le(15b+50)\delta<J\delta,\qquad J=2^{3206}.
\tag{H3}
\]

δJ<1/6，A>5/3，所以 D∞:=I(0)>3/2，e∞:=1/D∞<1。
定义辅助电荷

\[
Q_\infty(x)=\frac{\delta\int_x^\infty CR^2}{D_\infty}.
\]

0≤Q∞≤1，且

\[
|e_\infty-\lambda|\le J\delta<2^{4000}\delta,
\qquad
\frac{Q_\infty(x)}{R(x)^2}=\frac{I(x)}{I(0)}
\le1+2J\delta\le e^{C_0\delta},\quad C_0=2^{4000}.
\tag{H4}
\]

这个辅助系统的 e∞一般不等于 μ。它仅用于精确比较；没有把实际根的耦合改成 λ 或 e∞。

## 4. 有效尾区正性

冻结 N₀=2^4002=4C₀，X=N₀T<2^4025。
由 (H2)，对 x≥X，

\[
\frac{Q_\infty(x)}{R(x)}\le e^{C_0\delta}R(X)
\le e^{-\delta(C_0-4)}\le e^{-\delta}.
\]

设 r(t)=R(-log t)，

\[
H_\infty(t)=t-\int_0^t\frac{Q_\infty^2}{r^2}ds.
\]

该积分存在，因为 (H4) 给 Q∞²/R²≤e^(2C₀δ)。令 x=-log t，则

\[
\frac{H_\infty(e^{-x})}{e^{-x}}
=\int_0^\infty e^{-y}\left(1-\frac{Q_\infty(x+y)^2}{R(x+y)^2}\right)dy
\ge1-e^{-2\delta}\ge\delta\quad(x\ge X).
\tag{H5}
\]

最后一步用 δ≤1/4 和 e^-z≤1-z+z²/2（z≥0）。X 是在 δ 之前固定的有限整数，没有循环选参。

## 5. 紧区间的二阶余项，全部常数显式

设 P(s)=∫₀ˢp，F(s)=∫₀ˢC，S(s)=∫₀ˢq。由 (H1)，

\[
0\le S-\delta P\le b^2\delta^2s,\qquad0\le S\le b\delta s,
\quad0\le F\le bs.
\]

指数 Taylor 余项给

\[
|R^{-2}-(1+2\delta P)|
\le2b^2\delta^2(s+s^2)e^{2b\delta s}
\le\delta^2 2^{6405}(1+s)^2e^{2b\delta s}.
\tag{H6}
\]

因为 Q∞=1-e∞δ∫₀ˢCR²、|e∞-λ|≤δC₀、1-R²≤2bδs，

\[
|Q_\infty-(1-\lambda\delta F)|
\le\delta^2(C_0bs+b^2s^2)
\le\delta^2 2^{7202}(1+s)^2.
\]

由 0≤Q∞≤1、0<λ<1，|Q∞+1-λδF|≤2+bδs≤2e^(bδs)，得到

\[
|Q_\infty^2-(1-2\lambda\delta F)|
\le\delta^2 2^{7205}(1+s)^2e^{b\delta s}.
\tag{H7}
\]

把 (H6)、(H7) 相乘，保留交叉项 -4λδ²FP。用 |1-2λδF|≤e^(2bδs)，可得

\[
\left|\frac{Q_\infty(s)^2}{R(s)^2}
-1-2\delta(P(s)-\lambda F(s))\right|
\le\delta^2 A_2(1+s)^2 e^{4b\delta s},
\]

\[
A_2=2^{12000},\qquad
2^{7205}+2^{6405}+4b^2<2^{12000}.
\tag{H8}
\]

这里各次幂可在很大的 s 上非常粗；下面的 e^-y 仍使它可积，未把小 s 展开冒充全局小误差。
定义

\[
I_C(x)=F(x)+\int_x^\infty e^{x-s}C(s)ds,
\]

\[
I_E(x)=\int_0^xE(s)ds-\frac12p(x)
+\frac12\int_x^\infty e^{x-s}E(s)ds.
\]

直接交换积分得 ∫₀∞e^-yF(x+y)dy=I_C(x)、∫₀∞e^-yP(x+y)dy=I_E(x)。
因此一阶系数精确为冻结的自然耦合核

\[
2(\lambda I_C-I_E)=\mathcal K_{c,\mathrm{per}}(x)>2^{-855}.
\]

例如 x=0 时 I_E(0)=½∫₀∞e^-sE，故核等于 L020/L021 使用的 2λ∫e^-sC-∫e^-sE；没有更换核的定义。

对 0≤x≤X，4bδ<1/2、4bδX<1/2，且 e^(1/2)<2。
把 (H8) 积分，令 a₀=1-4bδ≥1/2、A₀=1+X，

\[
\int_0^\infty e^{-a_0y}(A_0+y)^2dy
=A_0^2/a_0+2A_0/a_0^2+2/a_0^3
\le26A_0^2<32A_0^2.
\]

所以紧区间的完整余项≤δ²2^12006(1+X)²<δ²C_X，取

\[
\boxed{C_X=2^{20100}}.
\]

这里 1+X<2^4026，所以 12006+2·4026=20058<20100。
δ≤2^-22000 保证 C_Xδ≤2^-856，所有前述小量条件也满足。
故

\[
H_\infty(t)\ge\delta 2^{-856}t\quad(0<t\le1).
\tag{H9}
\]

所有常数及选参条件已由 check_stage3.py 作精确有理／整数复算；它检查常数，不替代本节解析证明。

## 6. 与有限根的精确比较

原有限电荷为 Q_L(x)=1-μδ∫₀ˣCR²。端点根 μδ∫₀ᴸCR²=1 给

\[
Q_L(x)=\frac{Q_\infty(x)-Q_\infty(L)}{1-Q_\infty(L)},\qquad0\le x\le L.
\]

因为 C≥0，0≤Q_L≤Q∞。Minkowski 初始膨胀要求

\[
t_1=e^{-L},\quad\rho=R(L),\quad q_1=q(L),\quad
\beta=q_1\rho/t_1>0,\quad H_L(t_1)=\rho/\beta=t_1/q_1.
\]

相减的精确恒等式为

\[
H_L-H_\infty=t_1(1/q_1-1)
+\int_0^{t_1}\frac{Q_\infty^2}{r^2}dt
+\int_{t_1}^{t}\frac{Q_\infty^2-Q_L^2}{r^2}dt\ge0,
\]

因为 0<q₁<bδ<1。于是

\[
\boxed{H_L(t)\ge2^{-856}\delta t>0\quad(t_1\le t\le1)},\qquad
r_U=-H_L/(4r)<0.
\tag{H10}
\]

这覆盖整段有限脉冲，包含最后的电真空空隙；不是只在第一周期或领先阶成立。

## 7. 中心延伸与端点球面数据的界定

令 t_c=t₁-ρ/β<0。在出射锥的平直前段 t_c≤t≤t₁，冻结

\[
r=\beta(t-t_c),\quad H=t-t_c,\quad r_U=-1/(4\beta),
\quad\ell=0,\quad\Phi=Q=A_U=0.
\]

所以整锥的正半径部分 H>0；**轴线点 r=0 时 H=0，而 H/r=1/β>0**。不能把正则轴线登记为严格 H>0 点。
若需要中心参数 s=(t-t_c)/(1-t_c)∈[0,1]，则全锥 H/s 有固定成员的正下界：
平直段 H/s=1-t_c；脉冲段 H/s≥δ2^-856t₁。因此不存在沿本次固定锥趋于零的 H/s 余量，但它当然不在 m→∞ 时统一非退化。
同时取 \(\widetilde U=(1-t_c)U\)，有 \(-dUdt=-d\widetilde Uds\)，仍保持初始 lapse 为 1。
这是同一物理成员的互逆仿射重参数化；耦合 μ 不变，端点协变横向 jets 的消失也保持。上述 H 本身定义在原 U 规范；新规范的 H 需乘正因子 (1-t_c)^-1，符号不变。

在 (0,1) 的 r=Q=1、r_t=0、r_U<0、Φ=0 及 8 阶协变标量 jets 为零，按三角转换给普通 U jets 至 8 阶为零。
切向 jets 在 x∈[0,2^-1000] 的共同空隙为零。最高 ∂_U^9 r 用 U-Raychaudhuri 约束恢复，A_U 的第 8 个 U jet 用势输运恢复，不需要第 9 个复残差。
依 KU Definition 2.3、Proposition 2.3 及 Lemma 4.2，这些是完整 D₈ 的 ERN 规范轨道条件（质量、电荷均为 1）。
这是有限阶球面数据匹配的接口核对；实际双侧接合域及共同 Cauchy 面仍需落实。端点有限阶匹配不产生 C∞ 接合。
