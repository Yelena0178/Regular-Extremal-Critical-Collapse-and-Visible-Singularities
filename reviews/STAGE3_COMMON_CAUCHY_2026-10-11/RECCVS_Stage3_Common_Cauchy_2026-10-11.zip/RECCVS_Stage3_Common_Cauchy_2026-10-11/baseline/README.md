# 阶段 3 交付与复算

先读 REPORT.md。整锥 H 与第一周期初始输入已认证；共同 Cauchy 实现、AL 目标域、严格陷俘和光滑修复均未登记为已完成。

结构：PROOF_H.md 为新正性证明；FILL_AND_INPUTS.md 为填充、坐标和第一周期证明；certificates/ 为分项证书与根交接；code/ 为复算器；verification/ 为结果；baseline/ 为原完整阶段 2 包；sources/ 为原稿及固定版本文献的章节／来源哈希索引。

Python 3.10+，仅标准库。不要用 python -O。从本包根目录运行：

```bash
python3 code/check_manifest.py .
python3 baseline/code/check_manifest.py baseline
python3 code/check_stage3.py baseline/certificates/ROOT_CERTIFICATE_mgeom.json verification/recomputed_stage3
python3 code/independent_check.py .
python3 baseline/code/root_certificate.py baseline/certificates/EFFECTIVE_JET_BOUNDS.json baseline/certificates/PARTIAL_CERTIFICATE_mgeom.json verification/recomputed_root.json
python3 baseline/code/independent_majorant_check.py baseline/certificates/EFFECTIVE_JET_BOUNDS.json verification/recomputed_majorants.json
```

check_stage3 检查新解析证明的全部列明常数、参数同一性和第一周期包络；independent_check 不导入生成器，另以线性符号运算核验自然核恒等式及常数／scope 一致性。它们不是数值 PDE 求解器；解析推导和外部定理假设必须同时阅读。

根以盒内唯一根表示；t1=exp(-mT)、beta=q(L)rho/t1 保留精确表达式，避免天文尺度的下溢／溢出。两个 certificate 的 root_sha256 必须与 baseline 原根相同。

原 Stage 1 的未完成事项和原 Stage 2 scope 保持历史状态；新结果只登记在本轮分项证书。不要把未覆盖的共同时空／强修复字段改成 true。
