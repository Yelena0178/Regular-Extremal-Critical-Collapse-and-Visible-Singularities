# 16 实维有限端点根：复算说明

先读 `REPORT.md` 和 `PROOF.md`。根认证范围为冻结的有限 K=8 端点系统。整时空、H>0、中心填充、共同实现及 An–Lim 应用尚未验收。

主整数 m=2³⁵²²⁸⁴；另外认证 mgeom=2²¹⁰⁴¹⁵⁶。旧 m=2¹²⁰⁰⁰ 仍未由新粗界认证。

- `code/`：有效常数生成、独立正有理数复核、根证书组装检查、上一轮标量/矩阵检查和文件完整性检查。
- `certificates/`：有效八阶常数、标量消元输入和两份根证书。
- `verification/`：本轮复核结果。
- `sources/`：未修改的 L020/L021、D001、FLIFT、端点匹配、半径正性和首轮标量证明等来源。
- `SOURCE_MANIFEST.json`、`MANIFEST.json`：来源及交付完整性清单。

Python 3.10+，仅标准库。不要使用 `python -O`；断言是复算检查的一部分。以下从包根目录运行：

```bash
python3 code/check_manifest.py .
python3 code/jet_majorants.py verification/recomputed_bounds.json
python3 code/independent_majorant_check.py certificates/EFFECTIVE_JET_BOUNDS.json verification/recomputed_majorant_check.json
python3 code/r01_exact.py sources/experiments/filtered_K8_n88_sigma1over20.json verification/recomputed_coupling352284.json 352284
python3 code/independent_check.py sources/experiments/filtered_K8_n88_sigma1over20.json certificates/COUPLING_CERTIFICATE_m352284.json certificates/PARTIAL_CERTIFICATE_mgeom.json verification/recomputed_coupling_check.json
python3 code/root_certificate.py certificates/EFFECTIVE_JET_BOUNDS.json certificates/COUPLING_CERTIFICATE_m352284.json verification/recomputed_root352284.json
python3 code/root_certificate.py certificates/EFFECTIVE_JET_BOUNDS.json certificates/PARTIAL_CERTIFICATE_mgeom.json verification/recomputed_root_geom.json
```

可用 Python 的 `json.load` 将重算数据与原数据逐项比较。`root_certificate.py` 已核对归一化、16×16 精确逆、参数指数、边界主条件及标量包含；`independent_majorant_check.py` 不导入生成器，用另一套正有理 Taylor/geometric 系数方法检查全部上界。

`COUPLING_CERTIFICATE_m352284.json`、`PARTIAL_CERTIFICATE_mgeom.json` 以及 `INDEPENDENT_COUPLING_CHECK.json` 沿用上一轮程序的“部分证书／横向未验证”状态字段：该程序只知道标量和领先矩阵。完整新结论必须联合读取 `EFFECTIVE_JET_BOUNDS.json`、`PROOF.md` 和 `ROOT_CERTIFICATE_*.json`；不得篡改历史部分证书的 scope。

dyadic 常数以整数 exponent 记录，表示 2 的该次幂；无需把天文整数转换为小数。κ̂以十六进制分子除以 2⁴³⁰⁰。区间 lo_hex、hi_hex 除以 2 的 binary_scale 次幂。

此证书用解析有限输运上界产生残差/Jacobian 区间，再做 Krawczyk 检验，不逐周期数值积分，也不提供未计算的根小数。独立数学审阅仍需核对 `PROOF.md` 的权重代数和零阶输入。

进度：本轮有限端点根与复算包完成；剩余根后几何、共同实现及独立审阅；卡点为旧较小 m 的粗界及整时空接口；下一步见报告。
