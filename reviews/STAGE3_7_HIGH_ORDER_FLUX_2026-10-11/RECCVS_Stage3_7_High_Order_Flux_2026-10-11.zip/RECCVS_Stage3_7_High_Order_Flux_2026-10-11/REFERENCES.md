# 来源与核验状态

## 项目解析输入

baseline/保存本轮实际用到的九份冻结文件。阶段3.6/上一轮固定图包：RECCVS_Stage3_Past_Cauchy_Surface_2026-10-11；实际环带与有限正则约化接口来自RECCVS_Stage3_Effective_Cauchy_2026-10-11；共同实现与根身份沿用此前阶段3归档。所有文件摘要见verification/MANIFEST.json。

根证书SHA256：7845f2276b7dc12669d9e27861704bdee99f395458c35647fc9c734f93fb6dc2。根μ=3/5、m_geom=2^2104156。没有调整图参数或改造填充。

## 外部原始文献

Hughes, Kato, Marsden (1977), “Well-posed quasi-linear second-order hyperbolic systems with applications to nonlinear elastodynamics and general relativity”, Archive for Rational Mechanics and Analysis 63, 273–294.

- 出版页：https://link.springer.com/article/10.1007/BF00251584
- 作者存档：https://www.cds.caltech.edu/~marsden/bib/1977/02-HuKaMa1977/HuKaMa1977.pdf
- 本轮查得Theorem III公开索引陈述：有限Sobolev初值局部适定性，附(a1)–(a3)条件。作者PDF全文取回失败，未核完整(a1)–(a3)。仅据其陈述核对H⁶×H⁵的阶数门槛，不能当作全文逐条核验完成。
- 若需补原文，只需该文§3的方程、(a1)–(a3)及Theorem III（约pp.280–282，以实际分页为准）；本轮未因此暂停已授权推导。

Kehle–Unger项目原本使用的arXiv:2211.15742（本地v2，2024-02）§5.1及Lemma5.1。baseline/KU_CAUCHY_EXCERPT.txt保留本轮所核项目接口摘录。其小截断论证为H⁴/Cᵏ接口，未提供本轮所需命名H⁶假设对照；不移植其结论来填充缺口。

此包的新通量和H⁶常数是本轮解析推导，不是由上述文献或算术程序独立认证。
