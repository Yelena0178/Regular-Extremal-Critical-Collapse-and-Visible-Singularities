全部数学结论：GPT 主张，未经外部独立审查。

阅读PROOF.md与SELF_REVIEW.md。执行 python code/check_jets.py。baseline仅含必要冻结输入，继承的阶段3.7/3.8预算在正文逐项声明，不包含完整历史。
