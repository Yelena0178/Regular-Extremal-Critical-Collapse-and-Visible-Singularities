GPT 主张，未经外部独立审查。

阅读PROOF.md、SELF_REVIEW.md。运行python code/check_G.py。baseline仅保留必要来源，不是完整研究历史。
