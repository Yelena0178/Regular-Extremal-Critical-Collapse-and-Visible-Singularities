GPT 主张，未经外部独立审查。

读PROOF.md与SELF_REVIEW.md；执行python code/check_strip.py。baseline是必要冻结输入，不是完整历史。
