全部数学结论：GPT 主张，未经外部独立审查。

W. W.-Y. Wong, A comment on the construction of the maximal globally hyperbolic Cauchy development, J. Math. Phys. 54, 113511 (2013), arXiv:1310.1318v3. https://arxiv.org/html/1310.1318v3 §V. 仅使用其抽象框架对局部存在/唯一性的要求，不作为有限H6 EMCSF模型的适定性证明。
