"""Document/archive consistency only. No mathematical proof replay.
GPT 主张，未经外部独立审查。
"""
from pathlib import Path
import json, hashlib

ROOT=Path(__file__).resolve().parents[1]
lock=json.loads((ROOT/'SOURCE_LOCK.json').read_text())
status=json.loads((ROOT/'SUMMARY_STATUS.json').read_text())
for name, entry in lock['stage_archive_files'].items():
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==entry['sha256'],name
for name, digest in lock['context_files'].items():
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
results={}
for stage,count in status['historical_check_counts'].items():
    r=json.loads((ROOT/'stages'/stage/'verification/RESULTS.json').read_text())
    assert r['all_passed'] is True and r['number_of_checks']==count,stage
    results[stage]={'recorded_checks':count,'recorded_all_passed':True,'rerun_in_this_summary':False}
old=json.loads((ROOT/'stages/3.12/STATUS.json').read_text())
latest=json.loads((ROOT/'stages/3.13/STATUS.json').read_text())
assert old['selection']==latest['selection']
assert latest['selection']['conditional_actual_fixed_slice'] is True
assert latest['selection']['unconditional_certification'] is False
assert latest['selection']['original_psi_identity_with_candidate_certified'] is False
assert status['psi0']['conditional_actual_fixed_slice'] is True
assert status['psi0']['unconditional_certification'] is False
assert status['psi0']['same_H6_x_budget_certified'] is False
assert status['psi0']['numeric_Pa_necessary_for_candidate_upgrade'] is False
assert status['stage3_unconditionally_closed'] is False
assert status['external_independent_review_completed'] is False
assert status['current_summary_math_replay_performed'] is False
assert status['stage4']['status']=='proposed outline only; no derivation performed'
assert status['A_D_proved'] is False
s38=json.loads((ROOT/'stages/3.8/STATUS.json').read_text())
assert s38['compact_jet_envelope_certified'] is False
assert s38['complete_explicit_budget_certified'] is False
assert s38['root_sha256']==old['member']['root_sha256']==latest['member']['root_sha256']
assert old['member']==latest['member']
replay=json.loads((ROOT/'stages/3.13/verification/BASELINE_RECHECK.json').read_text())
assert replay['number_of_checks']==116 and replay['all_passed'] is True
report=(ROOT/'REPORT.md').read_text()
for phrase in ['GPT 主张，未经外部独立审查','条件固定','无条件认证','本轮完成项','剩余项','卡点','下一步','阶段 3 剩余工作','阶段 4','U1','U2','U3','U4','U5']:
    assert phrase in report,phrase
audit={
 'label':'GPT 主张，未经外部独立审查',
 'scope':'existing record and archive consistency; no proof/PDE certification',
 'all_passed':True,
 'unchanged_stage_files':len(lock['stage_archive_files']),
 'unchanged_context_files':len(lock['context_files']),
 'historical_verification_records':results,
 'stage313_baseline_replay_record_verified':True,
 'summary_conditional_state_matches_latest':True,
 'stage4_outline_only':True,
 'historical_math_scripts_rerun':False,
 'PDE_certification':False,
 'external_independent_review':False}
(ROOT/'verification').mkdir(exist_ok=True)
(ROOT/'verification/SUMMARY_AUDIT.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:audit[k] for k in ['all_passed','unchanged_stage_files','unchanged_context_files','historical_math_scripts_rerun','PDE_certification']},ensure_ascii=False))
