# 阶段 3.13 原始来源核验

**数学适用性判断：GPT 主张，未经外部独立审查。** 访问与正文定位是来源记录；从来源到本模型的适配是本文的推断，未宣称原作者认证本项目。日期：2026-10-12（项目文件日期沿用前轮）。未复制文献全文。

| 来源 | 本轮可核对位置 / 获取状态 | 实际边界与采用方式 |
|---|---|---|
| Hughes–Kato–Marsden (1977), *Well-posed quasi-linear second-order hyperbolic systems...* | [Caltech 作者记录](https://authors.library.caltech.edu/records/yqzjw-rqj49)，摘要及 metadata-only 说明；旧作者 PDF 地址返回 502 | 摘要支持一般拟线性局部理论背景；不声称已全文核完 Theorem III 的全部假设。本轮直接展开模型主符号，完整适定性验收仍保留 |
| Kommemi, arXiv:1107.0949 | [PDF](https://arxiv.org/pdf/1107.0949)，§1.1.4，PDF 第 5 页 | 来源明确使用 smooth 数据与唯一 smooth maximal future development。仅支持光滑带电模型背景，不能直接替代有限 H6 双向发展 |
| Chruściel, arXiv:1112.5779v2 | [PDF](https://arxiv.org/pdf/1112.5779)，Thm.1.1；§3.1 PDF 第 11–12 页；§3.2 第 19–21 页；Appendix B | 主定理是真空；§3.1 的 H1/H2、A0–A3 用作接口清单。H7 坐标波、H6 拉回和 isometry 正则性需在本带电系统及 gauge 中验收 |
| Parlongue, arXiv:1109.0644 | [PDF](https://arxiv.org/pdf/1109.0644)，§2 第 3–4 页，式(7)、Thm.2.0.3；§3 坐标导数论证 | 几何唯一性以 s-admissibility 为前提，要求固定背景 matter 的适定性/传播与稳定性。charged potential 的全部适配未完成；标量/Maxwell 的个别例子不等于自动覆盖耦合规范系统 |
| Wong, arXiv:1310.1318v3 | [作者 HTML](https://arxiv.org/html/1310.1318v3)，Def.18、Thm.21、Remark10 | 抽象最大构造要求存在、唯一性、唯一延拓、局部性。Sobolev 类别与重叠闭合需另外验证；未从抽象框架凭空取得本模型局部定理 |
| Kauffman–Lindblad, arXiv:2109.03270 | [PDF](https://arxiv.org/pdf/2109.03270)，Thm.1.5 | 光滑小 AF 初值的全局稳定性；本项目巨大预算不符合该小数据用途，不用于关闭固定候选接口 |
| Huneau 作者讲义 | [PDF](https://huneau.perso.math.cnrs.fr/cours.pdf)，Thm.4.3.4、5.1.1 | 变量系数线性定理的较强系数要求、半线性示例不能不加适配地当作完整 H6 拟线性系统证明；本轮仅作排除性检查 |

## 对照接口的可审查要求

- **H1/H2**：本项目全部 16 个实场分量的局部约化存在、同 wave 坐标/初值唯一性和有限传播；PROOF §4–5 的规范恢复需配线性能量唯一性。
- **A0/A1**：固定初面的等距自同构唯一性与 H7 的兼容映射；还须同步 U(1) 场识别。
- **A2/A3**：坐标波在 H7 的非特征初值和 trace、逆映射与 H6 拉回；不能只写一个粗波能量式。
- **Matter admissibility**：固定 H6 背景下的 charged Maxwell–scalar（含规范）的适定性、局部性与稳定性；不以平直 MKG 冒充动态 g。
- **Globality**：Hausdorff 的重叠拼接、Sobolev 类别闭合与规范 cocycle；局部几何唯一性本身不足以认证所有全局步骤。

本轮来源判断仅给出认证路线及适用限制；详细模型推导属于 PROOF 的 GPT 主张。没有依据文献标题、摘要或高阶数就把 ψ₀ 升级为无条件认证。
