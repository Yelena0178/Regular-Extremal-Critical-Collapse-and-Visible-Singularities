# 保留同一成员相位的约化初始化：C_red

日期：2026-10-11。内部解析稿，须独立数学审查。μ=3/5，空间坐标为上一稿真实 Σ 的 Cartesian areal 坐标。反向时间 s=0 放在原 Σ 上；反射后的物理数据为 (γ,−K,−E,B,Φ,−Π)。以下 K,E,Π 指已反射的数据。

## 1. 为什么必须补入空间势迹

原物理 tuple 未包含 \(\mathfrak a_i=A|_\Sigma\)。若要求保留 Φ 的原相位，同时将 \(\mathfrak a_i\) 当作约化位移变量，则不存在只由该 tuple 控制的统一 C_red：取纯规范势 dχ、物理 F=Φ=Π=0，物理 tuple 不变而势迹可任意大。若改令 \(\mathfrak a_i=0\)，必须同步改变 Φ 相位及其空间共变导数，不能直接保持原 Φ 后宣称是同一数据。

本轮修复采用同一实际势的空间迹，不做空间相位变换。N7_ACTUAL_ANNULUS.md 的显式 N₇ 同时支配势迹。对势迹和物理数据使用同一径向 cutoff。因势迹径向且 B=0，截断后 curl 势迹仍为零，与截断磁场相容。约束仅在原定真实内球要求成立。

定义 q 为所有截断物理差分及势迹的 Cartesian H⁴ 分量平方和平方根。分量数≤32，上一轮截断证明原封有效：
\[
q\le q_\varepsilon:=2^{600}N_7\varepsilon^3.\tag{1}
\]
因此下述 C_red 相对于这个**增强输入预算**。不能再把它解释为任意未给势迹的物理 tuple 的初始化算子范数。

## 2. 明确的约化变量及初值

度量初值 g₀₀=−1、g₀ᵢ=0、gᵢⱼ=γᵢⱼ。未来反向法向为 ∂s。令 H^α=g^{βγ}Γ^α_βγ，初始化
\[
\begin{aligned}
\partial_sg_{ij}&=-2K_{ij},\\
\partial_sg_{00}&=2\operatorname{tr}_\gamma K,\\
\partial_sg_{0i}&=\gamma^{kl}
(\partial_k\gamma_{li}-\tfrac12\partial_i\gamma_{kl}).
\end{aligned}\tag{2}
\]
直接代入 Christoffel 给 H^α=0；此公式的时间方向已随 K 反射，不能再额外翻号。

选择在 Σ 上值为零的电磁规范函数、以法向导数把 A₀ 置零。空间势、Φ 的初始相位不变，法向共变导数 Π 不变。设
\[
A_0=0,\quad A_i=\mathfrak a_i,\qquad
\partial_sA_i=E_i,\quad
\partial_sA_0=\gamma^{ij}\partial_i\mathfrak a_j,
\quad \partial_s\Phi=\Pi.\tag{3}
\]
于是 F₀ᵢ=Eᵢ，并且 L₀:=g^{αβ}∂αAβ=0。因 H=0，L₀ 等于物理 Lorenz 散度 ∇αA^α。初始 A₀=0 只选择电磁法向规范，不更改 root 参数。

约化变量 U=(g−η,A,ReΦ,ImΦ)，共有≤22 个实分量。范数固定为
\[
X(U,V)=\left(\sum_I\|U^I\|_{H^4}^2+
\sum_I\|V^I\|_{H^3}^2\right)^{1/2},\qquad V=\partial_sU.
\tag{4}
\]
度量对称分量按完整矩阵计入时≤16，预算仍覆盖。重要的是位移 H⁴、速度 H³，不是未经证明的全套变量 H⁴×H⁴。空间 ∂γ、∂\(\mathfrak a\) 只出现在 H³ 的速度中，无导数损失。

## 3. 明确范数常数

采用无权 Cartesian 多指标 Hᵏ 范数，Fourier 变换取 unitary 规范。∫(1+|ξ|²)^-2dξ=π² 给 H²→L∞ 常数在 Bessel 范数下<1；换成多指标范数可取 2。对 H³、H⁴ Leibniz，至少一因子导数阶≤1、≤2，分别可用 H²→L∞；多指标至四阶≤35，系数和≤16。因此标量/小矩阵乘积统一取
\[
\|fg\|_{H^k}\le2^{20}\|f\|_{H^k}\|g\|_{H^k},\quad k=3,4.\tag{5}
\]
矩阵常数因子当作常数乘法；不把恒等矩阵错误计入全空间 L²。

若 q≤2^-30，则 γ−I 的 H⁴ 矩阵分量总范数≤2⁴q，2²⁰·2⁴q≤2^-6。Neumann 级数在该 Banach 代数收敛，
\[
\|\gamma^{-1}-I\|_{H^4,\,sum}\le2\|\gamma-I\|_{H^4,\,sum}.
\]
正定性也由 H²→L∞ 保证。故用 γ^-1 乘 H³ 量的算子范数≤2；∂γ 的 H³ 分量总范数≤2⁴倍 γ 差的 H⁴ 范数。将 (2)–(3) 的系数、分量重复、平方和与分量总和转换均计入，初始状态满足
\[
X_0\le2^{20}q\le\boxed{C_{red}q_\varepsilon},
\qquad\boxed{C_{red}=2^{100}}.\tag{6}
\]
2²⁰ 的较紧预算已够，2¹⁰⁰ 保留余量。q≤2^-30 是明确输入门槛；最后 ε 会同时满足它与小数据寿命门槛。

## 4. 为后续寿命固定完整约化系统

定义 Dα=∂α+iμAα、F=dA，J_λ=μ Im(\barΦ D_λΦ)。D001 的 Ricci 右侧为
\[
S_{ab}=2F_{ac}F_b{}^c-\tfrac12g_{ab}F_{cd}F^{cd}
+2\Re(D_a\Phi\overline{D_b\Phi}).
\]
使用以下对角波主部约化：
\[
\begin{aligned}
R_{ab}-\tfrac12(g_{a\rho}\partial_bH^\rho+
g_{b\rho}\partial_aH^\rho)&=S_{ab},\\
\nabla_\alpha F^{\alpha}{}_{\lambda}+\partial_\lambda L_0&=J_\lambda,\\
D^\alpha D_\alpha\Phi&=0.
\end{aligned}\tag{7}
\]
标量式是完整协变波方程，包含 H 的第一导数度量系数项；不要提前用 H=0 删除它。Maxwell 的 L₀ 是坐标散度；它在 H=0 时才等于 Lorenz 散度。

展开 Maxwell 散度并加入 ∂λL₀，g^{αβ}∂αλAβ 的混合二阶势项精确抵消，剩余为 g^{αβ}∂αβAλ 及 ∂g·∂A。度量 harmonic 主部为 −g^{αβ}∂αβg_ab/2；标量主部为 g^{αβ}∂αβΦ。因而整个 (7) 是相同 Lorentz 主符号的对角 quasilinear 波系统，所有非线性只含 U、∂U、g^-1。

## 5. 为什么在真约束区恢复完整方程

完整标量方程保证 ∇αJ^α=0。对约化 Maxwell 取散度，反对称 F 的双散度为零，故 □gL₀=0。初始 L₀=0；其法向导数由 Maxwell 时间分量与 Gauss 约束为零，**仅在真实内球**成立。

在该内球的依赖域，L₀=0，Maxwell 方程恢复，物质应力守恒。Bianchi 恒等式于是给 H 的齐次波传播；H 初值为零，法向导数由 Hamiltonian/momentum 约束为零。故 H=0，Einstein 方程恢复，L₀ 为 Lorenz 散度。外部 cutoff 约束可以不满足，不据此声称整个约化解是物理解。

这一步同时保证有限传播与 Cauchy 唯一性识别适用于同一真实数据；它不是算术程序已经验证的命题，须独立解析审查。
