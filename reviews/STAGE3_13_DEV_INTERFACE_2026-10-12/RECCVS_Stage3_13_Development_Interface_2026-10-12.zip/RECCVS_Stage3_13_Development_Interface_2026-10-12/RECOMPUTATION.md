# 精确复算记录：阶段 3.13

**所有数学结论：GPT 主张，未经外部独立审查。** 环境 Python 3.12.14；仅标准库 Fraction 与附带形式多项式引擎。无浮点大指数实例化，无外部 CAS，未使用采样图替代证明。

## 结果

本轮 **433 项全部通过**；前轮 **116 项全部通过**并与冻结结果 JSON 精确相等。两组共 549 项，其中包括证据身份和依赖顺序检查，不能统称 549 个数学定理。

| 检查组 | 项数 | 范围 |
|---|---:|---|
| 冻结 SHA256 | 28 | 前轮证据及两份接口文本的字节身份 |
| 端点对象与前轮一致 | 4 | member、candidate、selection、path |
| 状态/根身份 | 3 | 条件固定、ψa 身份未认证、根摘要 |
| Maxwell 混合二阶消项 | 4 | 四个输出分量，符号系数精确为零 |
| 点度量逆与时间 guard | 6 | 三组非对角有理 Lorentz 度量 |
| Einstein 主部 | 300 | 每组点度量的 100 个独立二阶 metric-jet 基；每基检查全部 10 个输出 |
| harmonic/L0/约束初始符号 | 16 | 四组非对角 γ 的精确初始化 |
| Q 协变化 first-jet 系数 | 40 | 10 个对称 (a,b)，4 个收缩方向 |
| 应力 trace/source、Gauss、U(1)、电流共轭 | 5 | 形式代数消项；不证明 PDE 守恒本身 |
| 角长度与走廊余量、内图恒等式 | 8 | 有理安全因子及全 θ 形式身份 |
| 无环依赖顺序 | 19 | 条件接口逻辑链；不证明根前提 |
| **本轮合计** | **433** | 全部 passed |

前轮基线包括候选七阶 bump 预算、归一化下界、共同 d/J 界、类空/带权预算余量等 116 项；完整结果保留于 frozen/stage312/verification/RESULTS.json，本轮复跑记录见 verification/BASELINE_RECHECK.json。

## 重现

在解压后的包根目录运行：

```bash
python3 -B code/check_interface.py
python3 -B frozen/stage312/code/check_bounds.py
```

第二条会在冻结副本的 verification 写回确定性结果；原本的 SHA256 锁保留。若代码、输入或输出格式改变，首先核对 INPUT_LOCK；不要静默更新锁来掩盖变化。

本轮新结果与依赖图位于 verification/RESULTS.json、verification/DEPENDENCIES.json。MANIFEST.json 保存交付包内各文件散列，自身不自引用；ZIP 完整性另以打包后 CRC/成员字节验证。

## 解析与算术的边界

全度量的一般 Einstein 主符号仍是解析推导主张；三组有理点核验只检查系数实现。PDE 局部理论、几何唯一性、实际约束场、全局 Cauchy/最大性和 gauge 拼接均未由程序证明。所有对应状态保持 conditional / open，无外部独立审查。
