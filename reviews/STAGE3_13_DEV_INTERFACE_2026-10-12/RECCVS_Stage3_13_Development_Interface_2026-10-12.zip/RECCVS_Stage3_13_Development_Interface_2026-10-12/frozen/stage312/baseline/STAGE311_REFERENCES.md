# 来源与继承

GPT 主张，未经外部独立审查。

E. Minguzzi, On the regularity of Cauchy hypersurfaces and temporal functions in closed cone structures, arXiv:1909.09352v2, Theorem2.14（论文PDF第9页）：有限Ck(k≥2)类空Cauchy面可作为同正则Cauchy temporal函数的零水平。https://arxiv.org/pdf/1909.09352

G. Galloway, Notes on Lorentzian causality：Cauchy面与全局双曲、依赖域的关系见Proposition2.5及其后。https://www.math.miami.edu/~galloway/papers/cargproc.pdf

上述仅为几何接口。EMCSF有限H6存在、几何唯一性和MGHD的模型适配仍明确继承此前稿；本轮没有将真空或固定背景Maxwell结果当作charged-EMCSF定理。

冻结基线：COMMON_CAUCHY_REALIZATION_mgeom.md、MODEL.md、ROOT_CERTIFICATE_mgeom.json、阶段3.10 PROOF.md/STATUS.json、PSI_AUDIT.md。阶段3.6/3.7数值和Cauchy结论按正文显式继承，压缩包不是完整历史重建包。
