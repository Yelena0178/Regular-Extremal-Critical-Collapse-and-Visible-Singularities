# 阶段 3.12 交付包

**所有数学结论：GPT 主张，未经外部独立审查。**

- PROOF.md：主推导，含明确共同预算、端点证据、集中 bump 反例、固定决定及四项进度报告。
- SELF_REVIEW.md：本轮自审和中心坐标措辞修正。
- FIXED_SLICE.md：条件性固定切片及后续可用预算接口。
- RECOMPUTATION.md：精确复算方法、实际运行结果和适用限制。
- STATUS.json：机器可读验收与未闭合项。
- code/check_bounds.py：本轮可重复运行的精确有限计算。
- verification/RESULTS.json：逐项检查记录；MANIFEST.json：文件摘要。
- baseline/：前轮输入的只读副本与摘要，用于核对记号、根和条件；其历史结论状态以本轮主文和自审为准。

复算：在本包目录执行 `python3 code/check_bounds.py`。仅需要 Python 3 标准库；本包提供 Fraction 精确多项式/有理式交叉乘法，身份式以零分子检验；不需要网络或浮点巨数计算。本文不含新的外部模型专属适定性证书，也未补全原 ψa 的实际定义。
