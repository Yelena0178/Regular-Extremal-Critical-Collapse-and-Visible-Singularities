# 本轮来源与使用状态

**所有数学结论：GPT 主张，未经外部独立审查。**

本文主要复核前轮交付材料，未新增外部模型专属适定性认证。

| 本包基线 | 使用内容 | 限定 |
|---|---|---|
| COMMON_CAUCHY_REALIZATION_mgeom.md | 实际条带、d_base、RN 边函数、原 arbitrary ψ | 存在与接合为继承输入 |
| PSI_AUDIT.md | 原 ψ 定义缺失及候选 ψ₀ | 候选不认证原身份 |
| SIGMA_MINUS.md | 中心 harmonic 标签、α 椭圆界、面积半径 C1 估计 | 新切片输入为条件性 PDE 结果 |
| STAGE37_PHYSICAL_DATA_AND_INTERFACE.md | 近中心 H6 增强迹 B6 | 本轮未重新建立 |
| STAGE39_PROOF.md | 六阶归一化 jet、C_alg 包络 | 实际组合场输入由下一基线补足 |
| STAGE310_PROOF.md | D8、A² 强迫修正、组合场 S | 同一实际条带存在仍为前提 |
| STAGE311_PROOF.md、SELF_REVIEW.md、REFERENCES.md | G1/G2/G3、共同域与条件固定 | 中心全局 areal 措辞以本轮修正为准 |
| AF_REFERENCE_GAUGE.md | 径向规范相位、Bg、冻结全局标签 | 不更换物理成员 |
| STAGE38_WEIGHTED_INITIAL_BUDGET.md、FINAL_AUDIT_ADDENDUM.md | ERN 尾、主项、权积分 | 早期 Cψ 计数状态以后续 3.9–3.10 为准 |
| ROOT_CERTIFICATE_mgeom.json | 冻结文件身份摘要 | SHA 一致不等于重新认证根 |

主文的新界和反例由本轮直接推导；未声称被这些历史文件或外部文献独立验证。
