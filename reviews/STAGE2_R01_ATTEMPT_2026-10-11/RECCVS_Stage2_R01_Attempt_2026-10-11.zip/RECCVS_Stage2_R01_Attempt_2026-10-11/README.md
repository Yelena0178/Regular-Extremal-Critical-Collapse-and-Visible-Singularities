# RECCVS Stage 2 / R01 复算包

**完整有限 17 维根未认证。** `PARTIAL_CERTIFICATE` 仅包含领先映射与有限耦合标量方程的部分结果。先读 `REPORT.md`，再读 `R01_INTERFACE.md`。

目录内容：

- `code/`：本轮区间、有理矩阵、独立 Frobenius/L²/文件完整性脚本。
- `certificates/`：m=2¹²⁰⁰⁰ 和 mgeom=2²¹⁰⁴¹⁵⁶ 两份部分证书；横向未知字段为 `null`。
- `verification/`：原始复核结果。新复算输出可放在此目录的新文件中。
- `sources/`：未修改的相关证明稿、原领先剖面 JSON 和原有复算程序；来源详见 `SOURCE_MANIFEST.json`。
- `MANIFEST.json`：交付文件 SHA-256；排除其自身和后加的复算输出。

要求 Python 3.10+，仅使用标准库。运行时不要加 `-O`，检查器需要启用断言。以下从本包根目录执行；命令互相独立时仍须检查各退出码。

```bash
python3 code/check_manifest.py .
python3 code/r01_exact.py sources/experiments/filtered_K8_n88_sigma1over20.json verification/recomputed_m12000.json 12000
python3 code/r01_exact.py sources/experiments/filtered_K8_n88_sigma1over20.json verification/recomputed_mgeom.json 2104156
python3 code/independent_check.py sources/experiments/filtered_K8_n88_sigma1over20.json certificates/PARTIAL_CERTIFICATE_m12000.json certificates/PARTIAL_CERTIFICATE_mgeom.json verification/independent_recomputed.json
python3 code/check_profile_norm.py sources/experiments/filtered_K8_n88_sigma1over20.json verification/profile_norm_recomputed.json
python3 sources/experiments/certify_admissible_profile.py sources/experiments/filtered_K8_n88_sigma1over20.json verification/profile_recomputed.json
```

区间证书的 `lo_hex`、`hi_hex` 分别除以 2 的 `binary_scale` 次幂；κ̂ 的十六进制分子除以 2⁴³⁰⁰。所有显示小数均不参与验收。复算的预期结果是 `PARTIAL_CHECKS_PASS_FULL_R01_NOT_CERTIFIED`，不是完整根存在性。

有理矩阵采用两条不同推导交叉检查。12288 位重算使用同一向外舍入实现，属于精度复核，不冒充不同区间库的交叉认证。平滑截断和周期输入的解析证明见来源 L021；程序没有数值求解完整八阶输运。

进度：本轮部分结果已归档；剩余完整有限横向包络和全维认证；卡点为有效 C¹ 常数；下一步见报告 §8。
